# HackWithRudra Blog

This is a modern cybersecurity blog and tool showcase site built by HackWithRudra.

## Structure

- index.html: Main landing page
- blog.html: Blog articles
- tools.html: Security tools and downloads
- writeups.html: Writeups and walkthroughs
- hireme.html: Freelance or hiring info
- about.html: About Rudra
- contact.html: Contact form
- styles/: CSS styles
- scripts/: JavaScript functionality
- images/: Image assets

## Hosting

You can host it for free using [GitHub Pages](https://pages.github.com).

## License

Open source for educational use.
