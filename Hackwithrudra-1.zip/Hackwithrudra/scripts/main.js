// Theme Toggle
        const themeToggle = document.getElementById('themeToggle');
        const body = document.body;
        const icon = themeToggle.querySelector('i');
        
        // Check for saved theme preference
        const currentTheme = localStorage.getItem('theme');
        if (currentTheme === 'light') {
            body.classList.add('light-theme');
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        }
        
        themeToggle.addEventListener('click', () => {
            body.classList.toggle('light-theme');
            
            if (body.classList.contains('light-theme')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
                localStorage.setItem('theme', 'light');
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
                localStorage.setItem('theme', 'dark');
            }
        });
        
        // Mobile Menu Toggle
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinks = document.querySelector('.nav-links');
        
        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
        
        // Animation on scroll
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animated');
                }
            });
        }, observerOptions);
        
        document.querySelectorAll('.feature-card, .blog-card, .software-card').forEach(card => {
            observer.observe(card);
        });
        
        // Tool guides toggle
        function toggleTool(toolId) {
            const content = document.getElementById(`${toolId}-content`);
            const icon = document.querySelector(`#${toolId}-content`).previousElementSibling.querySelector('.fa-chevron-down');
            
            if (content.style.maxHeight) {
                content.style.maxHeight = null;
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            }
        }
        
        // Initialize tool guides
        document.querySelectorAll('.tool-content').forEach(content => {
            content.style.maxHeight = null;
        });
        
        // Chat functionality
        const chatButton = document.getElementById('chatButton');
        const chatContainer = document.getElementById('chatContainer');
        const closeChat = document.getElementById('closeChat');
        const chatMessages = document.getElementById('chatMessages');
        const userInput = document.getElementById('userInput');
        const sendMessage = document.getElementById('sendMessage');
        
        let chatOpen = false;
        
        chatButton.addEventListener('click', () => {
            chatOpen = !chatOpen;
            if (chatOpen) {
                chatContainer.classList.add('open');
            } else {
                chatContainer.classList.remove('open');
            }
        });
        
        closeChat.addEventListener('click', () => {
            chatOpen = false;
            chatContainer.classList.remove('open');
        });
        
        function addMessage(message, isUser) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message');
            messageDiv.classList.add(isUser ? 'user-message' : 'bot-message');
            messageDiv.textContent = message;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        
        sendMessage.addEventListener('click', () => {
            const message = userInput.value.trim();
            if (message) {
                addMessage(message, true);
                userInput.value = '';
                
                // Simulate bot response after a delay
                setTimeout(() => {
                    const responses = [
                        "I can help you with cybersecurity tools, techniques, and best practices. What specifically are you working on?",
                        "Great question! Would you like step-by-step instructions or general guidance?",
                        "I recommend checking the documentation for that tool. Is there a specific issue you're encountering?",
                        "For security reasons, I can't provide exploit code, but I can explain concepts and methodologies.",
                        "Have you tried checking our tools section? It has detailed guides on common cybersecurity tools.",
                        "Remember to always get proper authorization before testing systems! Ethical hacking requires permission."
                    ];
                    
                    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                    addMessage(randomResponse, false);
                }, 1000);
            }
        });
        
        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage.click();
            }
        });
        
        // Add sample messages on page load
        setTimeout(() => {
            addMessage("What's the best way to scan for open ports?", true);
            setTimeout(() => {
                addMessage("For port scanning, I recommend using Nmap. You can start with 'nmap -sS target_ip' for a SYN scan. Check out the tools section for detailed guides!", false);
            }, 1500);
        }, 3000);
        
        // Software category filtering
        const categoryButtons = document.querySelectorAll('.category-btn');
        const softwareCards = document.querySelectorAll('.software-card');
        
        categoryButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Update active button
                categoryButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                // Filter software cards
                const category = button.getAttribute('data-category');
                
                softwareCards.forEach(card => {
                    if (category === 'all' || card.getAttribute('data-category') === category) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
        
        // Download button functionality
        document.querySelectorAll('.btn-download').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const softwareName = this.closest('.software-card').querySelector('h3').textContent;
                
                // Show download confirmation
                addMessage(`Starting download for ${softwareName}...`, false);
                
                // Simulate download process
                setTimeout(() => {
                    addMessage(`${softwareName} download complete! Check your downloads folder.`, false);
                }, 2000);
            });
        });